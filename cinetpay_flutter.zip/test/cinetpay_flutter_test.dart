import 'package:flutter_test/flutter_test.dart';

import 'package:cinetpay_flutter/cinetpay_flutter.dart';

void main() {
  test('adds one to input values', () {
    // final calculator = CinetpayFlutter();
    // expect(() => calculator.addOne(null), throwsNoSuchMethodError);
  });
}
